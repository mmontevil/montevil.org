
/*SAMA: Plugin to send instructions to cran R
    
    Copyright (C) 2015 Maël Montévil and Tessie Paulose 

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

import ij.gui.GenericDialog;

import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import ij.plugin.frame.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Map;
import java.util.Map.Entry;

import java.io.BufferedInputStream;

 class RbSSortie extends Thread{
	private Process p;
	public RbSSortie(Process p0){
		
	 p=p0;
	}
	
      public void run(Process p) {
         try {
           InputStream is = p.getInputStream();
           BufferedReader br = new BufferedReader(new InputStreamReader(is));
           
           for(;;){
              String s = br.readLine();
              IJ.log("S "+s);
           }
         } catch (IOException ioe) {IJ.log("I/O Error: " + ioe);}
     }
   }  
   class RbSErreur extends Thread{
  	private Process p;
	public RbSErreur(Process p0){
	 p=p0;
	} 	
         public void run() {
            try {
              InputStream is = p.getErrorStream();
              BufferedReader br = new BufferedReader(new InputStreamReader(is));
              for(;;){
                 String s = br.readLine();
                 if(s==null) break;
                 IJ.log( s);
              }
            } catch (IOException ioe) {}
        }
   }
public class R_bind_sama implements PlugIn {
String winpath;
	String Rcom="";
        public void run(String arg) {
        	if (!showDialog())
           	 	return;        
		this.execCode(Rcom);
        
        }
    public boolean showDialog() {
        GenericDialog gd = new GenericDialog("Lauch R command");
	gd.addStringField("R command:", "getwd()");
        gd.showDialog();
        if (gd.wasCanceled())
            return false;
        Rcom = gd.getNextString();
        Rcom="message("+Rcom+")";
        return true;
   }
    public static String getRpath() {
    	String samaPathtoR=IJ.getDirectory("plugins")+"Rpath.txt";
    	File f = new File (samaPathtoR);
    	if(!f.isFile())
    		{chooseRpath(); }
		String rPath=IJ.openAsString(samaPathtoR); 
    	return removeLastChar(rPath);
    }
     public static void chooseRpath() {
     	String samaPath=IJ.getDirectory("plugins");
		String rPath=IJ.getDirectory("Please select the path to R executable.");
		IJ.saveString(rPath,samaPath+"Rpath.txt");
    }  
         public static Boolean  isWin() {
				return IJ.isWindows();
		} 
private static String removeLastChar(String str) {
        return str.substring(0,str.length()-1);
    }
    
        public static Boolean execCode(String cmdString){
        String[] cmdString2;
             
        	if(IJ.isWindows() ){
			String pref=getRpath() ;
			//String pref2="c:/Program Files/R/R-3.1.1/bin/i386/";
			cmdString=cmdString.replaceAll( "\\\\","/");
			
			//String[] temp={"cmd.exe","/c","start","/b","/d",pref,"Rcmd.exe","-e","for(i in 1:100000){1+1}"};
			//String[] temp={"cmd.exe","/c","start","/b","/d",pref2,"R.exe","-e",cmdString,">","loglog.log"};
			     	String samaPath=IJ.getDirectory("plugins");
		IJ.saveString(cmdString ,samaPath+"Rcommand.r");
			String[] temp={pref+"R.exe","-f",samaPath+"Rcommand.r"};
			 cmdString2=temp;
        	 }
 else{
                String[] temp={"R","-v","-e","message(\"R started successfully\");","-e",cmdString};
			 cmdString2=temp;
        	 }
  
                Boolean result=true;
                try {    
                	IJ.log("Starting cran R...");                                                                                        
                        Process p = Runtime.getRuntime().exec(cmdString2);
                        RbSErreur err = new RbSErreur(p); 
                       RbSSortie s = new RbSSortie(p);  
err.start(); s.start();
     	        BufferedInputStream in = new BufferedInputStream(p.getInputStream());
        byte[] bytes = new byte[4096];
        while (in.read(bytes) != -1) {}		     
     			 p.waitFor();
                }
                catch (Exception e) {    
			IJ.log("Problem "+e);                                                             
                        result=false;                                                                          
                }

		    IJ.log("Closing R successfully");
                return result;
        }
} 


